import NoProfile from "./userprofile.png";
import BgImage from "./img.jpeg";
export { NoProfile, BgImage };
